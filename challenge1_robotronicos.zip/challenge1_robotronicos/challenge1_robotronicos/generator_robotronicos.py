import rclpy
from rclpy.node import Node
import numpy as np

from std_msgs.msg import Float32  # Cambiamos a Float32

class SignalGenerator(Node):
    def __init__(self):
        super().__init__('generator_robotronicos')
        self.publisher_t = self.create_publisher(Float32, 'time_robotronicos', 10)  # Usamos Float32
        self.publisher_s = self.create_publisher(Float32, '/signal_robotronicos', 10)  # Usamos Float32
        timer_period = 0.1  # seconds (10Hz)
        self.timer = self.create_timer(timer_period, self.timer_callback)
        self.time_timer = 0.0
        self.time_signal = 1.0

    def timer_callback(self):
        #time
        time_msg = Float32()
        time_msg.data = self.time_timer
        self.publisher_t.publish(time_msg)

        # Generar una señal sinusoidal
        s_msg = Float32()  # Usamos Float32
        s_msg.data = np.sin(self.time_timer*self.time_signal)
        self.publisher_s.publish(s_msg)
        self.get_logger().info(f'time: {time_msg.data}')
        #self.get_logger().info(f'time: {time_msg.data}, signal: {s_msg.data}')
        self.get_logger().info(f'signal: {s_msg.data}')
        self.time_timer += 0.1  # Incrementar el tiempo para la siguiente señal

def main(args=None):
    rclpy.init(args=args)
    generator_robotronicos = SignalGenerator()
    try:
        rclpy.spin(generator_robotronicos)
    except KeyboardInterrupt:
        pass
    finally:
        if rclpy.ok():
            rclpy.shutdown()
        generator_robotronicos.destroy_node()

if __name__ == '__main__':
    main()