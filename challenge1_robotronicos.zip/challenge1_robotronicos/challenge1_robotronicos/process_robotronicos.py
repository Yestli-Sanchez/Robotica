import rclpy
import time
import numpy as np
from rclpy.node import Node
from std_msgs.msg import Float32  # Usamos Float32 para coincidir con el generador

class ProcessNode(Node):
    def __init__(self):
        super().__init__('process_robotronicos')

        # suscriptor para recibir el time
        self.subscription_t = self.create_subscription(Float32, 'time_robotronicos', self.time_callback, 10)
        # Suscriptor para recibir la señal generada
        self.subscription_s = self.create_subscription(
            Float32,  # Tipo de mensaje
            '/signal_robotronicos',  # Tópico de la señal generada
            self.signal_callback,  # Función de callback
            10  # Tamaño de la cola
        )
        
        ## Publicador para la señal procesada
        self.publisher_proc = self.create_publisher(
            Float32,  # Tipo de mensaje
            '/proc_signal_robotronicos',  # Tópico de la señal procesada
            10  # Tamaño de la cola
        )

        self.timer = 0.0
        self.processed_signal = 0.0

        self.get_logger().info('Process node initialized, waiting for signal...')

    def time_callback(self, msg):
        self.timer = msg.data

    def signal_callback(self, msg):
        # Procesar la señal multiplicándola por 2
        self.processed_signal = msg.data
        self.processed_signal = np.sin((self.timer+1.0)*2.0)
        self.proc = self.processed_signal * 2.0
        
        # Crear un mensaje para la señal procesada
        processed_msg = Float32()
        processed_msg.data = self.proc
        
        # Publicar la señal procesada
        self.publisher_proc.publish(processed_msg)
        self.get_logger().info(f'Processed signal: {processed_msg.data}')

        # Agregar un pequeño retraso antes de publicar (no es necesario, pero puede ayudar a evitar sobrecargar la CPU)
        time.sleep(0.1)  # Retardo de 0.1 segundos (opcional)


def main(args=None):
    rclpy.init(args=args)
    process_robotronicos = ProcessNode()

    try:
        rclpy.spin(process_robotronicos)
    except KeyboardInterrupt:
        pass
    finally:
        if rclpy.ok():
            rclpy.shutdown()
        process_robotronicos.destroy_node()
    

if __name__ == '__main__':
    main()