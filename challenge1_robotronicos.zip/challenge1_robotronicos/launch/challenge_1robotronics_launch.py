from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    generator_robotronicos = Node(
        package='challenge1_robotronicos',  
        executable='generator_robotronicos',  
        output='screen'  
    )

    process_robotronicos = Node(
        package='challenge1_robotronicos',  
        executable='process_robotronicos',  
        output='screen'  
    )

    rqt_plot_node = Node(
        package='rqt_plot',  
        executable='rqt_plot',  
        arguments=['/signal', '/time', '/proc_signal'],  
        output='screen'  
    )

    rqt_graph_node = Node(
        package='rqt_graph',  
        executable='rqt_graph',  
        output='screen'  
    )

    launch_description = LaunchDescription([
        generator_robotronicos,
        process_robotronicos,
        rqt_plot_node,
        rqt_graph_node
    ])

    return launch_description
